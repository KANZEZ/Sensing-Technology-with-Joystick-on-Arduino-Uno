# 1 "c:\\Users\\29180\\Desktop\\JOYStick\\JOYStick.ino"




int read_x = 0;
int read_y = 0;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(A0 /* define */,0x0);
  pinMode(A1,0x0);
  pinMode(2,0x2);

}

void loop() {
  // put your main code here, to run repeatedly:

  read_x = analogRead(A0 /* define */);
  read_y = analogRead(A1);

  float vol_x = float(read_x)/1023.0*5*1000;
  float vol_y = float(read_y)/1023.0*5*1000;
  int read_button = digitalRead(2);

  Serial.print("x = ");
  Serial.print(vol_x);
  Serial.print("mv");
  Serial.print("  ");

  Serial.print("y = ");
  Serial.print(vol_y);
  Serial.print("mv");
  Serial.print("  ");

  Serial.print("button = ");
  Serial.print(read_button);
  Serial.print("  ");

  Serial.println();

  delay(200);

}
