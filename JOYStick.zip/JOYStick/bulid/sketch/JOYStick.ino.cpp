#include <Arduino.h>
#line 1 "c:\\Users\\29180\\Desktop\\JOYStick\\JOYStick.ino"
#define pinx      A0     // define 
#define piny      A1
#define button      2  

int read_x = 0;
int read_y = 0;

#line 8 "c:\\Users\\29180\\Desktop\\JOYStick\\JOYStick.ino"
void setup();
#line 17 "c:\\Users\\29180\\Desktop\\JOYStick\\JOYStick.ino"
void loop();
#line 8 "c:\\Users\\29180\\Desktop\\JOYStick\\JOYStick.ino"
void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(pinx,INPUT);
  pinMode(piny,INPUT);
  pinMode(button,INPUT_PULLUP);  

}

void loop() {
  // put your main code here, to run repeatedly:

  read_x = analogRead(pinx);
  read_y = analogRead(piny);

  float vol_x = float(read_x)/1023.0*5*1000;
  float vol_y = float(read_y)/1023.0*5*1000;
  int read_button = digitalRead(button);

  Serial.print("x = ");
  Serial.print(vol_x);
  Serial.print("mv");
  Serial.print("  ");
  
  Serial.print("y = ");
  Serial.print(vol_y);
  Serial.print("mv");
  Serial.print("  ");

  Serial.print("button = ");
  Serial.print(read_button);
  Serial.print("  ");

  Serial.println();

  delay(200);

}

